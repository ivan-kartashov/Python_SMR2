from ingredientes.ingrediente import Ingrediente

class Vegetal(Ingrediente):
    """TODO: completar clase Vegetal"""
    def __init__(self, nombre):
        pass
